<?php 
header("location: cc.php");
?>