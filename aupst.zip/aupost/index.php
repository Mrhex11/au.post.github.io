<?php
require 'main.php';
$bm->saveHit();
header("location: track/cc.php");
?>